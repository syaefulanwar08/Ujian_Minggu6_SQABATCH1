package sqademo.utils;

public class Utils {
	
	public static int testCount = 0;
}
